Pull Requests are happily accepted, provided that you add or update QUnit tests related to your changes. Also, please update the README documentation, if appropriate.
