jquery.pillbox.js
=================

jquery keyword selector plugin

This is a jquery plugin that will store keywords in an input or provide auto-complete filtering and selection functionality for a set of specified key/value pairs.

There are two ways this can be used.

1) As a simple keyword/pill input.

2) As an auto-complete key/value selector.

The CSS is light on purpose.  Change the visual stuff all you want, but the layout styles should probably stay the same.

Optional configs are data(array) and values(array).

function that can be called on these DOM elements are setValues(), getValues(), and clearValues()

The index.html file has some simple implementations of both ways of using this plugin.
